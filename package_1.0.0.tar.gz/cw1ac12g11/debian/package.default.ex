# Defaults for package initscript
# sourced by /etc/init.d/package
# installed at /etc/default/package by the maintainer scripts

#
# This is a POSIX shell fragment
#

# Additional options that are passed to the Daemon.
DAEMON_OPTS=""
